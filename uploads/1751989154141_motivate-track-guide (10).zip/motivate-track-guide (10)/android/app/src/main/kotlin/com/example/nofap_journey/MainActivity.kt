package com.example.nofap_journey

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
